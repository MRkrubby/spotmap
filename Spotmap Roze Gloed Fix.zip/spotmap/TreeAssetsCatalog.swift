import Foundation

/// Asset catalog for tree models bundled with the app.
enum TreeAsset: String {
    case lowPolyPack = "TreeAssets/LowPolyTrees.usdz"
}
