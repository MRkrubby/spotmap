import Foundation
import SwiftUI
import MapKit
import CoreLocation
import os
import Combine

/// A single cloud object shown on the map (fog-of-war made of "real" objects).
struct FogCloud: Identifiable, Hashable {
    let id: UInt64
    let coordinate: CLLocationCoordinate2D
    let sizePoints: CGFloat
    let altitudeMeters: Double
    let asset: CloudAsset
    let seed: UInt64

    static func == (lhs: FogCloud, rhs: FogCloud) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

/// Cloud field that:
/// - Keeps a bounded pool of cloud objects.
/// - Moves them continuously using a procedural wind/pressure field.
/// - Removes clouds inside "explored" areas (fog-of-war holes).
///
/// This avoids visible "tiles" while still supporting LOD + memory safety.
@MainActor
final class FogCloudField: ObservableObject {
    @Published private(set) var clouds: [FogCloud] = []

    // Tunables
    // A hard cap to protect UI responsiveness.
    // User wants clouds far apart and not cluttered.
    // NOTE: user wants: big clouds, clearly spaced, but still "a lot" visible.
    // We keep a moderate cap and drive density with a heuristic, while enforcing separation.
    // User request: raise the hard cap so more clouds can be visible.
    var maxClouds: Int = 125
    // Higher => fewer clouds (targetCount is inversely proportional to this).
    var targetCloudPixels: Double = 680
    // Lower tick rate = better battery + smoother UI.
    var simulationHz: Double = 1.2

    // If >0, keep a small amount of haze even in explored areas.
    // Keep some residual haze so the user still sees clouds even in partly explored areas.
    var exploredResidualChance: Double = 0.18

    private let log = Logger(subsystem: Bundle.main.bundleIdentifier ?? "spotmap", category: "CloudField")

    private var isRunning: Bool = false
    private var tickTask: Task<Void, Never>?

    private var store: FogOfWarStore?
    private var wind = WindField()

    // Viewport state
    private var visibleRect: MKMapRect = MKMapRect(x: 0, y: 0, width: 1, height: 1)
    private var metersPerPoint: Double = 1.0
    private var canvasSize: CGSize = .zero

    // Internal particle state (world units)
    private struct Particle {
        var id: UInt64
        var mp: MKMapPoint
        var sizePoints: CGFloat
        var altitudeMeters: Double
        var asset: CloudAsset
        var seed: UInt64
    }

    private var particles: [Particle] = []
    private var lastTickTime: TimeInterval?

    func clear() {
        particles.removeAll()
        clouds.removeAll()
    }

    func start(store: FogOfWarStore) {
        self.store = store
        guard !isRunning else { return }
        isRunning = true
        tickTask?.cancel()
        tickTask = Task { [weak self] in
            await self?.runLoop()
        }
        log.info("CloudField started")
    }

    func stop() {
        isRunning = false
        tickTask?.cancel()
        tickTask = nil
        store = nil
        lastTickTime = nil
        clear()
        log.info("CloudField stopped")
    }

    /// Call on camera changes (throttled by the caller).
    func updateViewport(proxy: MapProxy, canvasSize: CGSize) {
        self.canvasSize = canvasSize
        self.metersPerPoint = Self.estimateMetersPerPoint(proxy: proxy, canvasSize: canvasSize)
        self.visibleRect = Self.visibleMapRect(proxy: proxy, canvasSize: canvasSize)

        // Keep density LOW and spacing HIGH.
        // Zoomed in: still keep few clouds, just scale them larger.
        let clampedMPP = max(0.15, min(30, metersPerPoint))
        let zoomFactor = sqrt(clampedMPP) // ~0.4..5.5

        // More clouds than before, but still zoom-aware.
        // Smaller targetCloudPixels => more clouds (targetCount = screenArea / targetCloudPixels^2).
        targetCloudPixels = max(420, min(1100, 620 * max(0.45, zoomFactor)))

        // Rebuild published models immediately so UI doesn't feel laggy.
        publish()
    }

    /// Call when explored voxels change (driving reveals more).
    func exploredChanged() {
        // We don't rebuild everything; the tick loop prunes/respawns gradually.
        // But publishing helps show holes quickly.
        publish()
    }

    // MARK: - Loop

    private func runLoop() async {
        while !Task.isCancelled, isRunning {
            let now = Date().timeIntervalSince1970
            let dt: Double
            if let last = lastTickTime {
                dt = min(0.75, max(0.01, now - last))
            } else {
                dt = 1.0 / max(0.5, simulationHz)
            }
            lastTickTime = now

            step(time: now, dt: dt)
            publish()

            let sleepNs = UInt64(1_000_000_000 / max(0.5, simulationHz))
            try? await Task.sleep(nanoseconds: sleepNs)
        }
    }

    private func step(time: TimeInterval, dt: Double) {
        guard let store else { return }

        // If viewport isn't valid yet, don't do anything.
        guard visibleRect.size.width > 2, visibleRect.size.height > 2, canvasSize.width > 10, canvasSize.height > 10 else {
            return
        }

        // Cap particles.
        if particles.count > maxClouds {
            particles.removeLast(particles.count - maxClouds)
        }

        // Determine how many clouds we want for this viewport.
        let target = targetCount()

        // Move particles.
        for i in particles.indices {
            var p = particles[i]

            // Dissipate if explored (mostly).
            if store.isExplored(coordinate: p.mp.coordinate), Double.random(in: 0...1) > exploredResidualChance {
                // Respawn upwind instead of keeping it.
                if let newP = spawnParticle(upwindOf: visibleRect, store: store, time: time) {
                    particles[i] = newP
                }
                continue
            }

            let s = wind.sample(at: p.mp, time: time)
            p.mp = MKMapPoint(x: p.mp.x + s.vx * dt, y: p.mp.y + s.vy * dt)

            // Wrap around extended bounds so we never "endlessly generate".
            p.mp = wrapped(p.mp, in: visibleRect, time: time)

            particles[i] = p
        }

        // Fill until target count.
        if particles.count < target {
            let needed = min(target - particles.count, 24) // avoid spikes
            for _ in 0..<needed {
                if let p = spawnParticle(upwindOf: visibleRect, store: store, time: time) {
                    particles.append(p)
                } else {
                    break
                }
            }
        }

        // Trim if too many.
        if particles.count > target {
            particles.removeLast(particles.count - target)
        }
    }

    private func publish() {
        // Convert particles to published array.
        // NOTE: we keep this cheap and stable by not reshuffling.
        clouds = particles.map { p in
            FogCloud(
                id: p.id,
                coordinate: p.mp.coordinate,
                sizePoints: p.sizePoints,
                altitudeMeters: p.altitudeMeters,
                asset: p.asset,
                seed: p.seed
            )
        }
    }

    // MARK: - Spawning

    private func targetCount() -> Int {
        // A density heuristic based on screen size.
        let area = max(1.0, Double(canvasSize.width * canvasSize.height))
        // Smaller `per` => more clouds.
        let per = max(380.0, min(1400.0, targetCloudPixels))

        // Density: keep "many" clouds, but avoid a carpet.
        // - zoomed out => fewer clouds
        // - zoomed in  => a few more (but still spaced)
        let mpp = max(0.15, min(30, metersPerPoint))
        let zoom = sqrt(mpp) // ~0.4..5.5
        // Boost a bit so the user sees plenty of clouds, but we rely on the min-distance rule
        // to prevent clutter.
        let densityBoost = max(22.0, min(58.0, 40.0 / max(0.75, zoom)))

        let target = Int((area / (per * per)) * densityBoost)

        // Keep within bounds.
        return max(18, min(maxClouds, target))
    }

    private func spawnParticle(upwindOf rect: MKMapRect, store: FogOfWarStore, time: TimeInterval) -> Particle? {
        // Spawn clouds slightly outside the view, biased from the upwind side.
        let margin: Double = max(350, min(1800, metersPerPoint * 420))
        let ext = rect.insetBy(dx: -margin, dy: -margin)

        let center = MKMapPoint(x: ext.midX, y: ext.midY)
        let w = wind.sample(at: center, time: time)

        // Upwind direction.
        let wx = -w.vx
        let wy = -w.vy
        let wlen = max(0.001, hypot(wx, wy))
        let ux = wx / wlen
        let uy = wy / wlen

        // Choose a spawn line on the upwind edge.
        // We spawn on a segment orthogonal to wind.
        let halfW = ext.size.width * 0.55
        let halfH = ext.size.height * 0.55

        // Find a starting point far upwind.
        let startX = center.x + ux * max(halfW, halfH)
        let startY = center.y + uy * max(halfW, halfH)

        // Perp vector for randomization.
        let px = -uy
        let py = ux

        // Try a few times to avoid spawning directly in explored cells.
        for attempt in 0..<18 {
            let jitter = Double.random(in: -1...1)
            let span = (attempt < 6 ? 0.65 : 1.0) * max(halfW, halfH)
            let x = startX + px * jitter * span
            let y = startY + py * jitter * span

            let mp = MKMapPoint(x: x, y: y)

            // Keep within extended rect.
            guard ext.contains(mp) else { continue }

            if store.isExplored(coordinate: mp.coordinate), Double.random(in: 0...1) > exploredResidualChance {
                continue
            }

            let seed = mix64(UInt64(bitPattern: Int64(x.rounded())) ^ UInt64(bitPattern: Int64(y.rounded())) ^ UInt64(time * 1000))
            let id = seed

            let size = cloudSizePoints(seed: seed)
            let alt = cloudAltitude(seed: seed)
            let asset = chooseAsset(seed: seed)

            // Enforce separation so clouds don't look cluttered.
            // IMPORTANT: if we make size/separation too extreme, spawning can fail and you see 0 clouds.
            // So we relax the minimum distance after several failed attempts.
            // Keep clouds far apart, but not so extreme that nothing can spawn.
            let baseMinMeters = max(650.0, metersPerPoint * 1050.0)
            var sizeSepMeters = max(baseMinMeters, Double(size) * metersPerPoint * 0.95)
            if attempt > 10 { sizeSepMeters *= 0.75 }
            if attempt > 14 { sizeSepMeters *= 0.55 }

            if isTooClose(mp: mp, minMeters: sizeSepMeters) {
                continue
            }

            return Particle(id: id, mp: mp, sizePoints: size, altitudeMeters: alt, asset: asset, seed: seed)
        }

        return nil
    }

    private func isTooClose(mp: MKMapPoint, minMeters: Double) -> Bool {
        // Cheap O(n) check; n is small (<= maxClouds).
        let lat = mp.coordinate.latitude
        let metersPerMapPoint = MKMetersPerMapPointAtLatitude(lat)
        let minMapPoints = minMeters / max(0.0001, metersPerMapPoint)
        let minSq = minMapPoints * minMapPoints
        for p in particles {
            let dx = p.mp.x - mp.x
            let dy = p.mp.y - mp.y
            if (dx * dx + dy * dy) < minSq {
                return true
            }
        }
        return false
    }

    private func wrapped(_ mp: MKMapPoint, in rect: MKMapRect, time: TimeInterval) -> MKMapPoint {
        // Wrap within a margin so clouds recycle instead of endlessly spawning.
        let margin: Double = max(450, min(2500, metersPerPoint * 520))
        let ext = rect.insetBy(dx: -margin, dy: -margin)

        var x = mp.x
        var y = mp.y

        // Use a global-ish wind at center to decide wrap direction.
        let c = MKMapPoint(x: rect.midX, y: rect.midY)
        let w = wind.sample(at: c, time: time)

        if w.vx >= 0, x > ext.maxX { x = ext.minX }
        if w.vx < 0, x < ext.minX { x = ext.maxX }
        if w.vy >= 0, y > ext.maxY { y = ext.minY }
        if w.vy < 0, y < ext.minY { y = ext.maxY }

        return MKMapPoint(x: x, y: y)
    }

    private func cloudSizePoints(seed: UInt64) -> CGFloat {
        // Clouds should be BIG and readable.
        let base = max(0.15, min(30, metersPerPoint))
        let zoom = sqrt(base)
        var rng = SplitMix(seed: seed)
        let s = (0.75 + 0.55 * rng.nextDouble())
        let px = Double(500 / max(0.50, zoom))
        // User request: clouds MUCH bigger, but keep within a sensible range.
        // (Too huge + too much separation can result in zero spawns.)
        return CGFloat(max(520, min(2200, (px * s) * 2.1)))
    }

    private func cloudAltitude(seed: UInt64) -> Double {
        var rng = SplitMix(seed: seed ^ 0xA5A5A5A5A5A5A5A5)
        // User request: clouds should sit LOWER above buildings.
        // Keep a smaller real-world range so the 3D effect is still visible
        // when the map is pitched, but doesn't look like they're in the stratosphere.
        // 25m..220m
        return 25 + 195 * rng.nextDouble()
    }

    private func chooseAsset(seed: UInt64) -> CloudAsset {
        // Weighted: stylized most of the time.
        let r = Double((seed >> 16) & 0xFFFF) / Double(0xFFFF)
        if r < 0.68 { return .stylized }
        if r < 0.92 { return .cartoon }
        return .tiny
    }

    // MARK: - MapProxy helpers

    private static func estimateMetersPerPoint(proxy: MapProxy, canvasSize: CGSize) -> Double {
        let sample: CGFloat = 120
        let p1 = CGPoint(x: canvasSize.width * 0.5, y: canvasSize.height * 0.5)
        let p2 = CGPoint(x: min(canvasSize.width - 1, p1.x + sample), y: p1.y)
        guard let c1 = proxy.convert(p1, from: .local),
              let c2 = proxy.convert(p2, from: .local) else {
            return 1.0
        }
        let d = CLLocation(latitude: c1.latitude, longitude: c1.longitude)
            .distance(from: CLLocation(latitude: c2.latitude, longitude: c2.longitude))
        return max(0.001, Double(d) / Double(sample))
    }

    private static func visibleMapRect(proxy: MapProxy, canvasSize: CGSize) -> MKMapRect {
        let pts: [CGPoint] = [
            .init(x: 0, y: 0),
            .init(x: canvasSize.width, y: 0),
            .init(x: 0, y: canvasSize.height),
            .init(x: canvasSize.width, y: canvasSize.height)
        ]

        var minX = Double.greatestFiniteMagnitude
        var minY = Double.greatestFiniteMagnitude
        var maxX = -Double.greatestFiniteMagnitude
        var maxY = -Double.greatestFiniteMagnitude

        for p in pts {
            guard let c = proxy.convert(p, from: .local) else { continue }
            let mp = MKMapPoint(c)
            minX = min(minX, mp.x)
            minY = min(minY, mp.y)
            maxX = max(maxX, mp.x)
            maxY = max(maxY, mp.y)
        }

        if minX.isFinite, minY.isFinite, maxX.isFinite, maxY.isFinite {
            return MKMapRect(x: minX, y: minY, width: max(1, maxX - minX), height: max(1, maxY - minY))
        }

        return MKMapRect(x: 0, y: 0, width: 1, height: 1)
    }

    // MARK: - Hash / RNG

    private func mix64(_ x: UInt64) -> UInt64 {
        var z = x &+ 0x9E3779B97F4A7C15
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }

    private struct SplitMix {
        private var state: UInt64
        init(seed: UInt64) { self.state = seed &+ 0x9E3779B97F4A7C15 }
        mutating func nextUInt64() -> UInt64 {
            state &+= 0x9E3779B97F4A7C15
            var z = state
            z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
            z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
            return z ^ (z >> 31)
        }
        mutating func nextDouble() -> Double {
            Double(nextUInt64() >> 11) / Double(1 << 53)
        }
    }
}

