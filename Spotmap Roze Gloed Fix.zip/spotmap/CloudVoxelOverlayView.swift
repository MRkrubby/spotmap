import SwiftUI
import SceneKit
import UIKit
import simd

/// A renderable cloud item in view coordinates.
///
/// We keep this as screen-space (points) because SwiftUI's `Map` provides
/// fast coordinate-to-point conversion through `MapProxy`.
struct CloudVoxelItem: Identifiable, Hashable {
    let id: UInt64
    let screenPoint: CGPoint
    let sizePoints: CGFloat
    let altitudeMeters: Double
    let asset: CloudAsset
    let seed: UInt64
}

/// True 3D voxel/low-poly clouds rendered in a single SceneKit view.
///
/// Key behaviors:
/// - Clouds are placed in *screen space* (given by `CloudVoxelItem.screenPoint`).
/// - The cloud *models* do NOT rotate with map/camera yaw or pitch (per your requirement).
/// - A stable, per-cloud base tilt/roll is applied for variation.
struct CloudVoxelOverlayView: UIViewRepresentable {
    let items: [CloudVoxelItem]
    let headingDegrees: Double
    let pitchDegrees: Double
    let viewportSize: CGSize

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView(frame: .zero)
        v.isOpaque = false
        v.backgroundColor = .clear
        v.allowsCameraControl = false
        v.autoenablesDefaultLighting = false
        v.antialiasingMode = .multisampling4X
        v.rendersContinuously = false
        v.isPlaying = false

        v.scene = context.coordinator.scene
        context.coordinator.configureIfNeeded(for: v)
        return v
    }

    func updateUIView(_ scnView: SCNView, context: Context) {
        context.coordinator.update(items: items, viewportSize: viewportSize)
    }

    // MARK: - Coordinator

    final class Coordinator {
        let scene = SCNScene()
        private let root = SCNNode()
        private let cameraNode = SCNNode()

        // Cache nodes per cloud id to avoid re-creating geometry each frame.
        private var cloudNodes: [UInt64: SCNNode] = [:]

        // Prototypes loaded from bundled USDZ assets.
        private var prototypes: [CloudAsset: SCNNode] = [:]

        // Stable base rotations per cloud id.
        private var baseRotations: [UInt64: (x: Float, z: Float)] = [:]

        private var didConfigure: Bool = false

        init() {
            scene.rootNode.addChildNode(root)

            let cam = SCNCamera()
            cam.usesOrthographicProjection = true
            cam.orthographicScale = 500 // updated per-frame
            cam.zNear = 0.1
            cam.zFar = 10000
            cameraNode.camera = cam
            cameraNode.position = SCNVector3(0, 0, 1200)
            scene.rootNode.addChildNode(cameraNode)

            // Lighting tuned for soft, low-poly look.
            let dir = SCNLight()
            dir.type = .directional
            dir.intensity = 1100
            let dirNode = SCNNode()
            dirNode.light = dir
            dirNode.eulerAngles = SCNVector3(-0.9, 0.65, 0)
            scene.rootNode.addChildNode(dirNode)

            let amb = SCNLight()
            amb.type = .ambient
            amb.intensity = 340
            let ambNode = SCNNode()
            ambNode.light = amb
            scene.rootNode.addChildNode(ambNode)
        }

        func configureIfNeeded(for view: SCNView) {
            guard !didConfigure else { return }
            didConfigure = true

            // Ensure the SceneKit layer keeps alpha.
            view.layer.isOpaque = false
            view.layer.backgroundColor = UIColor.clear.cgColor
            view.pointOfView = cameraNode
        }

        func update(items: [CloudVoxelItem], viewportSize: CGSize) {
            // Prevent implicit SceneKit animations when we update transforms.
            SCNTransaction.begin()
            SCNTransaction.disableActions = true

            // Keep camera fixed.
            if let cam = cameraNode.camera {
                cam.usesOrthographicProjection = true
                cam.orthographicScale = Double(max(200.0, viewportSize.height * 0.5))
            }
            cameraNode.eulerAngles = SCNVector3(0, 0, 0)

            // Move origin to center of view.
            root.position = SCNVector3(-Float(viewportSize.width * 0.5), Float(viewportSize.height * 0.5), 0)

            // Remove missing.
            let incoming = Set(items.map { $0.id })
            for (id, node) in cloudNodes where !incoming.contains(id) {
                node.removeFromParentNode()
                cloudNodes.removeValue(forKey: id)
                baseRotations.removeValue(forKey: id)
            }

            for item in items {
                let node: SCNNode
                if let existing = cloudNodes[item.id] {
                    node = existing
                } else {
                    node = makeAssetCloud(asset: item.asset, seed: item.seed)
                    cloudNodes[item.id] = node
                    root.addChildNode(node)
                }

                // Position in "screen space" SceneKit coordinates.
                let x = Float(item.screenPoint.x)
                let y = Float(item.screenPoint.y)

                // Height: map field provides meters -> Scene units.
                let z = Float(min(28, max(0, item.altitudeMeters * 0.06)))
                node.position = SCNVector3(x, -y, z)

                // Scale: map-bound (points) -> Scene scale.
                let scaleBase: Float
                switch item.asset {
                case .stylized: scaleBase = 0.95
                case .cartoon:  scaleBase = 0.88
                case .tiny:     scaleBase = 0.74
                }
                let s = Float(max(0.06, item.sizePoints / 360.0)) * scaleBase
                node.scale = SCNVector3(s, s, s)

                // Stable base tilt/roll (NO yaw, NO map heading/pitch).
                let base: (x: Float, z: Float)
                if let cached = baseRotations[item.id] {
                    base = cached
                } else {
                    // Small variations only.
                    let baseX = Float((Double((item.seed >> 16) & 0xFFFF) / 65535.0 - 0.5) * 0.16)
                    let baseZ = Float((Double((item.seed >> 32) & 0xFFFF) / 65535.0 - 0.5) * 0.16)
                    base = (x: baseX, z: baseZ)
                    baseRotations[item.id] = base
                }

                let qPitch = simd_quatf(angle: base.x, axis: SIMD3<Float>(1, 0, 0))
                let qRoll  = simd_quatf(angle: base.z, axis: SIMD3<Float>(0, 0, 1))
                node.simdOrientation = qPitch * qRoll
            }

            SCNTransaction.commit()
        }

        // MARK: - Helpers

        private static func centerPivot(_ node: SCNNode) {
            let (minV, maxV) = node.boundingBox
            let cx = (minV.x + maxV.x) * 0.5
            let cy = (minV.y + maxV.y) * 0.5
            let cz = (minV.z + maxV.z) * 0.5
            // IMPORTANT: pivot is a transform applied BEFORE node transforms.
            // To center the pivot, translate by the NEGATIVE center.
            node.pivot = SCNMatrix4MakeTranslation(-cx, -cy, -cz)
        }

        private func makeAssetCloud(asset: CloudAsset, seed: UInt64) -> SCNNode {
            let proto: SCNNode
            if let cached = prototypes[asset] {
                proto = cached
            } else {
                proto = loadPrototype(asset: asset) ?? Self.makeFallbackVoxelCloud()
                prototypes[asset] = proto
            }

            let node = proto.flattenedClone()
            Self.centerPivot(node)

            // Avoid halos: keep depth testing consistent.
            node.enumerateChildNodes { child, _ in
                child.geometry?.materials.forEach { m in
                    m.writesToDepthBuffer = true
                    m.readsFromDepthBuffer = true
                    if m.transparency < 1.0 { m.blendMode = .alpha }
                }
            }

            return node
        }

        private static func makeFallbackVoxelCloud() -> SCNNode {
            let container = SCNNode()

            let mat = SCNMaterial()
            mat.lightingModel = .physicallyBased
            mat.diffuse.contents = UIColor(white: 1.0, alpha: 0.96)
            mat.roughness.contents = 0.9
            mat.metalness.contents = 0.0

            let boxes: [(Float, Float, Float, Float)] = [
                (0, 0, 0, 1.3),
                (1.2, 0.25, 0.1, 0.95),
                (-1.1, -0.05, 0.0, 0.95),
                (0.25, 0.95, 0.0, 0.9),
                (-0.55, 0.85, -0.1, 0.82),
                (0.9, -0.85, 0.0, 0.85),
            ]

            for (x, y, z, s) in boxes {
                let g = SCNBox(width: CGFloat(120 * s), height: CGFloat(90 * s), length: CGFloat(90 * s), chamferRadius: 12)
                g.materials = [mat]
                let n = SCNNode(geometry: g)
                n.position = SCNVector3(x * 70, y * 60, z * 40)
                container.addChildNode(n)
            }

            Self.centerPivot(container)
            return container
        }

        private func loadPrototype(asset: CloudAsset) -> SCNNode? {
            // CloudAsset rawValue looks like "CloudAssets/StylizedCloud.usdz"
            let parts = asset.rawValue.split(separator: "/")
            let file = String(parts.last ?? "")
            let name = (file as NSString).deletingPathExtension
            let ext = (file as NSString).pathExtension

            // 1) Preferred: preserve folder reference in bundle.
            var url: URL? = nil
            if parts.count >= 2 {
                let subdir = String(parts.dropLast().joined(separator: "/"))
                url = Bundle.main.url(forResource: name, withExtension: ext, subdirectory: subdir)
            }

            // 2) Fallback: flattened resources.
            if url == nil {
                url = Bundle.main.url(forResource: name, withExtension: ext)
            }

            // 3) Last resort: search bundle.
            if url == nil, let resourceURL = Bundle.main.resourceURL {
                let fm = FileManager.default
                if let e = fm.enumerator(at: resourceURL, includingPropertiesForKeys: nil) {
                    for case let u as URL in e {
                        if u.lastPathComponent.lowercased() == (name + "." + ext).lowercased() {
                            url = u
                            break
                        }
                    }
                }
            }

            guard let url else {
                #if DEBUG
                print("[CloudVoxelOverlayView] Missing USDZ in bundle: \(asset.rawValue)")
                #endif
                return nil
            }

            guard let ref = SCNReferenceNode(url: url) else { return nil }
            ref.load()

            let container = SCNNode()
            container.addChildNode(ref)
            Self.centerPivot(container)
            return container
        }
    }
}
