import SwiftUI

@main
struct SpotMapApp: App {
    var body: some Scene {
        WindowGroup {
            RootTabView()
        }
    }
}
